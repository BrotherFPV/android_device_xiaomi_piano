#
# Copyright (C) 2026 The Android Open Source Project
# Copyright (C) 2026 SebaUbuntu's TWRP device tree generator
#
# SPDX-License-Identifier: Apache-2.0
#

add_lunch_combo omni_piano-user
add_lunch_combo omni_piano-userdebug
add_lunch_combo omni_piano-eng
