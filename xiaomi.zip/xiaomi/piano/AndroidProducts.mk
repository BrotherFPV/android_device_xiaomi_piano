#
# Copyright (C) 2026 The Android Open Source Project
# Copyright (C) 2026 SebaUbuntu's TWRP device tree generator
#
# SPDX-License-Identifier: Apache-2.0
#

PRODUCT_MAKEFILES := \
    $(LOCAL_DIR)/omni_piano.mk

COMMON_LUNCH_CHOICES := \
    omni_piano-user \
    omni_piano-userdebug \
    omni_piano-eng
